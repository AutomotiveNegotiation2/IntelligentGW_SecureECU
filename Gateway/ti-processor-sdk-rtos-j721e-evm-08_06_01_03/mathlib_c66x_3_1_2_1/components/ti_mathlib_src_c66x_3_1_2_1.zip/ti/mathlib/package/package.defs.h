/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z44
 */

#ifndef ti_mathlib__
#define ti_mathlib__



#endif /* ti_mathlib__ */ 
