/* ======================================================================== *
 * MATHLIB -- TI Floating-Point Math Function Library                       *
 *                                                                          *
 *                                                                          *
 * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/   *
 *                                                                          *
 *                                                                          *
 *  Redistribution and use in source and binary forms, with or without      *
 *  modification, are permitted provided that the following conditions      *
 *  are met:                                                                *
 *                                                                          *
 *    Redistributions of source code must retain the above copyright        *
 *    notice, this list of conditions and the following disclaimer.         *
 *                                                                          *
 *    Redistributions in binary form must reproduce the above copyright     *
 *    notice, this list of conditions and the following disclaimer in the   *
 *    documentation and/or other materials provided with the                *
 *    distribution.                                                         *
 *                                                                          *
 *    Neither the name of Texas Instruments Incorporated nor the names of   *
 *    its contributors may be used to endorse or promote products derived   *
 *    from this software without specific prior written permission.         *
 *                                                                          *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     *
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       *
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   *
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    *
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   *
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        *
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   *
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   *
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     *
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   *
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    *
 * ======================================================================== */

/* ======================================================================= */
/* asinhdp_i.h - Double precision floating point inverse hyperbolic sine   */
/*              optimized inlined C Implementation (w/ Intrinsics)         */
/* ======================================================================= */

#ifndef ASINHDP_I_
#define ASINHDP_I_ 1

#include <ti/mathlib/src/common/common.h>
#include <float.h>

static inline double divdp_asinhdp_i (double a, double b);
static inline double logdp_asinhdp_i (double x);
static inline double sqrtdp_asinhdp_i (double z, double x);
static inline double asinhdp_i(double x);

#ifndef __cplusplus         /* FOR PROTECTION PURPOSE - C++ NOT SUPPORTED. */
#pragma CODE_SECTION(divdp_asinhdp_i, ".text:optci");
#endif

/* ======================================================================= */
/* This function returns the division result of two real floating-point    */
/* values, a and b. The return value is a/b.                               */
/* ======================================================================= */

static inline double divdp_asinhdp_i (double a, double b)
{
  double  y, x1, x2, x3;
  const double  two   =  2.0;

  x1 = _rcpdp(b);
  x1 = x1 * (two - (b*x1));
  x2 = x1 * (two - (b*x1));
  x3 = x2 * (two - (b*x2));
  y = x3 * a;

  if (a == 0.0) {
    y = 0.0;
  }

  return (y);
} /* divdp_asinhdp_i */

#ifndef __cplusplus         /* FOR PROTECTION PURPOSE - C++ NOT SUPPORTED. */
#pragma CODE_SECTION(logdp_asinhdp_i, ".text:optci");
#endif

/* ======================================================================== */
/* This function returns the logarithm value of a real floating-point       */
/* argument x. The return value is the base e logarithmic value of x.       */
/* ======================================================================== */

static inline double logdp_asinhdp_i (double x)
{
  const double Half   =  0.5;
  const double srHalf =  0.70710678118654752440;      /* sqrt(0.5) */
  const double a0     = -0.64124943423745581147e+2;
  const double a1     =  0.16383943563021534222e+2;
  const double a2     = -0.78956112887491257267e+0;
  const double b0     = -0.76949932108494879777e+3;
  const double b1     =  0.31203222091924532844e+3;
  const double b2     = -0.35667977739034646171e+2;   /* Note b3 = 1.0 */
  const double c1     =  0.693359375;                 /*  355/512      */
  const double c2     = -2.121944400546905827679e-4 ;
  const double max    =  709.782712893384;
  double W, X, Y, Z;
  double zn, zd, zn_2, zd_2;
  double Rz, Sa, Bd, Cn, Da;
  unsigned int upper;
  int    N, exp_; 

  /* get unbiased exponent */
  Y = x;
  exp_ = (int)_extu(_hi(Y),1u,21u);
  N = exp_ - 1022;
    
  /* force SP exp = 1022 if not zero */
  upper = _clr(_hi(Y),20u,31u);
  upper = 0x3fe00000u | upper;
  Z = _itod(upper,_lo(Y));

  if (exp_ == 0) {
    Z = 0.0;
  }

  zn = (Z - Half) - Half;
  zd = (Z*Half) + Half;

  zn_2 = Z - Half;
  zd_2 = (zn_2*Half) + Half;

  if (Z <= srHalf) {
    zn = zn_2;
    zd = zd_2;
    N  = N - 1; 
  }

  X  = divdp_asinhdp_i(zn,zd);
  W  = X*X;
  Bd = ((((W + b2)*W) + b1)*W) + b0;
  Cn = (((W*a2) + a1)*W) + a0;
  Rz = W * divdp_asinhdp_i(Cn,Bd);
  Sa = X + (X*Rz);
  Cn = (double)N;
  Da = ((Cn*c2) + Sa) + (Cn*c1);

  if(x > DBL_MAX){
    Da = max;
  }

  return (Da);
} /* End of logdp_asinhdp_i */

#ifndef __cplusplus         /* FOR PROTECTION PURPOSE - C++ NOT SUPPORTED. */
#pragma CODE_SECTION(sqrtdp_asinhdp_i, ".text:optci");
#endif

/* ======================================================================== */
/* This function returns the square root of the argument a. This function   */
/* has been modified to return the argument x when a = x*x. The argument a  */
/* is equal to x * x + 1, if a = x* x then +1 is irrelevant or x * x        */
/* overflows and the real sqrt of a is lost.                                */
/* ======================================================================== */

static inline double sqrtdp_asinhdp_i (double z, double x)
{

  const double  half  =  0.5;
  const double  OneP5 =  1.5;
  double  x0, x1, x2, res;

  /*  z = a; */
  x0 = _rsqrdp (z);

  x1 = x0     * (OneP5 - (z*x0*x0*half));
  x2 = x1     * (OneP5 - (z*x1*x1*half));
  res = z * x2 * (OneP5 - (z*x2*x2*half));

  if(z == (x * x)){
    res = x;
  }

  return (res);
} /* End of sqrtdp_asinhdp_i */

#ifndef __cplusplus         /* FOR PROTECTION PURPOSE - C++ NOT SUPPORTED. */
#pragma CODE_SECTION(asinhdp_i, ".text:optci");
#endif

/* ======================================================================== */
/* The type of calculation for asinh(x) depends on the value of x:          */
/*   x_abs > 0.3, res =  ln( x + sqrt (x^2 + 1))                            */
/*   This equation is modified as follows to avoid overflow for a large x;  */
/*     ln([x + sqrt(x^2 + 1)]/2] + ln(2)                                    */
/*                                                                          */
/*   x_abs <= 0.3, res = polynomial estimation (input x)                    */
/* where x_abs is the absolute value of the input and res is the calculated */
/* value for asinh(x)                                                       */
/*                                                                          */
/* The polynomial used is as follows:                                       */
/*   pol = x + c2 x^3 + c4 x^5 + c6 x^7 + c8 x^8                            */
/* where x is the input, c2 through c8 are the corresponding coefficients   */
/* for the polynomial, and pol is the result of the polynomial.             */
/* ======================================================================== */

static inline double asinhdp_i(double x)
{
  const double ln2         =  0.693147180559945;   /* ln(2) */
  const double pol_bound   =  0.3;
  const double half        =  0.5;
  double sign              =  1.0;

  /* Coefficients for the polynomial */
  const double c2          = -0.166666692592182;
  const double c4          =  0.0750025275672600;
  const double c6          = -0.0447153024904795;
  const double c8          =  0.0310957306366509;
  const double c10         = -0.0229667510576129;

  double res, sqrt_, pol;
  double x2, x4, x6, x8, x10, x_abs;
  double temp;

  x_abs = _fabs(x);

  if(x < 0.0){
    sign = -sign;
  }

  /* powers of x */
  x2 = x * x;
  x4 = x2 * x2;
  x6 = x4 * x2;
  x8 = x4 * x4;
  x10 = x4 * x6;

  sqrt_ = sqrtdp_asinhdp_i(x2 + 1.0, x_abs);           /* sqrt(x^2 + 1) */

  /* polynomial to estimate asinh(x) for small inputs*/

  pol = ((x2 * c2) + (x4 * c4)) + ((x6 * c6) + (x8 * c8));
  res = ((pol + (c10 * x10)) * x) + x;

  /* asinh(x) estimation for values greater than 0.5 */
  /* prevent overflow for large x, log(2x) where x > max/2 */

  temp = (x_abs * half) + (sqrt_ * half);                /* (x+sqrt(x^2 + 1))/2 */
  temp = logdp_asinhdp_i(temp) + ln2;               /* ln((x + sqrt(x^2 + 1))/2) +ln(2) */

  /* set the value of the result depending on the input value */
  if(x_abs > pol_bound){
    res = temp * sign;                              /* restore sign */
  }

  return res;
}

#endif /* _ASINHDP_H_ */

/* ======================================================================= */
/*  End of file: asinhdp_i.h                                               */
/* ======================================================================= */

